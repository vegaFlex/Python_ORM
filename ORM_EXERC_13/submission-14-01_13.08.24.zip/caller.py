import os
import django

from populate_db_script import populate_model_with_data

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()



from main_app.models import Author, Book

def show_all_authors_with_their_books() -> str:
    result = []

    authors = Author.objects.all().order_by('id')
    for curr_author in authors:
        books = Book.objects.filter(author=curr_author)
        # books = Author.book_set.all()

        if not books:
            continue

        titles = ', '.join(book.title for book in books)

        result.append(f"{curr_author.name} has written - {titles}!")

        return "\n".join(result)

def delete_all_authors_without_books() -> None:
    Author.objects.filter(book__isnull=True).delete()

# ========================================================================

populate_model_with_data(Song)
populate_model_with_data(Song)














